Assignment_num="One"
from commonUtil import *
#from awsglue.context import GlueContext
import pandas as pd
import zipfile, boto3, gzip, io, os, re, sys, pyspark, yaml
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql import window
from pyspark.sql.window import *
from pyspark.sql.functions import *
from botocore.exceptions import ClientError
from datetime import datetime
from io import BytesIO
from pyspark.sql.types import *

spark=SparkSession.builder.appName("Assignment_1").getOrCreate()

bucketName="saama-gene-training-data-bucket"
s3 = boto3.client('s3')
response = s3.get_object(Bucket=bucketName, Key="amolkadam/Config/aws_config.yaml")
config = yaml.safe_load(response["Body"])

RootDir = config[Assignment_num]["aws.s3.RootDir"]
InboundDir = config[Assignment_num]["aws.s3.InboundDir"]
LandingDir = config[Assignment_num]["aws.s3.LandingDir"]
TempDir = config[Assignment_num]["aws.s3.TempDir"]
ArchiveDir = config[Assignment_num]["aws.s3.ArchiveDir"]
PreprocessDir = config[Assignment_num]["aws.s3.PreprocessDir"]
StandardizedDir = config[Assignment_num]["aws.s3.StandardizedDir"]
OutboundDir = config[Assignment_num]["aws.s3.OutboundDir"]

for file in getFileList(bucketName,InboundDir):
    if getFileExtension(file)=="xls" or getFileExtension(file)==".xlsx" or getFileExtension(file)=="csv":
        copyS3File(bucketName,file,bucketName,os.path.join(os.path.join(PreprocessDir,file.split("/")[-2]),os.path.basename(file)))
        
for file in getFileList(bucketName,PreprocessDir):
    loadToLanding(spark,bucketName,file,LandingDir)
    
for file in getFileList(bucketName,LandingDir):
    loadToStandard(spark,bucketName,file,StandardizedDir)
        
#print(startCrawler("saama-gene-training-amol-crawler"))
#print(startCrawler("saama-gene-training-amol-parquet-crawler"))

print("Data Summary load started")
for file in getFileList(bucketName,LandingDir):
    loadSummary(spark,bucketName,file,OutboundDir)

print("Data Summary load Finished")