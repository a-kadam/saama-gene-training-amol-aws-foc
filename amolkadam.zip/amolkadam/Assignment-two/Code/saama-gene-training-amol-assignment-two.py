Assignment_num="Two"
from commonUtil import *
#Extracting zip files

#from awsglue.context import GlueContext
import pandas as pd
import zipfile, boto3, gzip, io, os, re, sys, pyspark, yaml
from pyspark.context import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql import window
from pyspark.sql.window import *
from pyspark.sql.functions import *
from botocore.exceptions import ClientError
from datetime import datetime
from io import BytesIO
from pyspark.sql.types import *

spark=SparkSession.builder.appName("Assignment_2").getOrCreate()

bucketName="saama-gene-training-data-bucket"
s3 = boto3.client('s3')
response = s3.get_object(Bucket=bucketName, Key="amolkadam/Config/aws_config.yaml")
config = yaml.safe_load(response["Body"])

RootDir = config[Assignment_num]["aws.s3.RootDir"]
InboundDir = config[Assignment_num]["aws.s3.InboundDir"]
LandingDir = config[Assignment_num]["aws.s3.LandingDir"]
TempDir = config[Assignment_num]["aws.s3.TempDir"]
ArchiveDir = config[Assignment_num]["aws.s3.ArchiveDir"]
PreprocessDir = config[Assignment_num]["aws.s3.PreprocessDir"]
StandardizedDir = config[Assignment_num]["aws.s3.StandardizedDir"]
OutboundDir = config[Assignment_num]["aws.s3.OutboundDir"]

for file in getZipFileList(bucketName,InboundDir):
    print("Inbound file = {0}".format(file))
    unzip_file(bucketName,file,TempDir)

for file in getZipFileList(bucketName,TempDir):
    print("TempDir file = {0}".format(file))
    unzip_file(bucketName,file,TempDir)
    
archiveOldFiles(bucketName,TempDir,LandingDir,ArchiveDir)
for file in getFileList(bucketName,TempDir):
    loadFilestoLandingFolderwise(spark,bucketName,file,LandingDir)